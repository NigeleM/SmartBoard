#include <stdio.h>
#include <stdlib.h>

int main()
{
    system("python in.py");
    exit(0);
    return 0;
}
