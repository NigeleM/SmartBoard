# SmartBoard
# A clipboard that keeps
import os
import sys
import shutil

#print(sys.argv[0])
os.system("python in.py")
